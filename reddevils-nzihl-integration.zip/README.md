# Red Devils — NZIHL live data integration

Drop-in package that makes three sections of **reddevils.co.nz** populate themselves
from the official NZIHL site and refresh automatically every **Friday, Saturday and
Sunday at 11pm NZ**:

- **Fixtures** — full Red Devils season (results + upcoming, with ticket/stream links)
- **NZIHL Standings** — the league table
- **Top Scorers** — Red Devils points leaders

Nothing else in the site changes. The visual components stay exactly as they are —
you just swap each section's hardcoded array for a fetch (or a direct function call).

---

## What's in here

```
lib/nzihl/                 # ① the data layer (framework-agnostic)
  config.ts                #    IDs, URLs, team maps, tunables — start here
  types.ts                 #    TypeScript types for components
  fetcher.ts               #    fetch with timeout + UA
  parse.ts                 #    HTML parsers (cheerio) — validated vs live pages
  fallback.ts              #    snapshot used only if a scrape fails
  index.ts                 #    public API: getFixtures / getStandings / getTopScorers

app/api/nzihl/             # ② the API routes (App Router)
  fixtures/route.ts        #    GET /api/nzihl/fixtures
  standings/route.ts       #    GET /api/nzihl/standings
  scorers/route.ts         #    GET /api/nzihl/scorers
  revalidate/route.ts      #    POST /api/nzihl/revalidate  (the "refresh now" hook)

vercel.json                # ③ scheduler — Option A (Vercel Cron)
.github/workflows/nzihl-refresh.yml   # ③ scheduler — Option B (GitHub Action)
```

> Targets the **App Router**. If the site uses the **Pages Router**, see
> [Pages Router](#pages-router) below — the data layer (`lib/nzihl`) is identical;
> only the route/scheduler wrappers change.

---

## Install (≈10 minutes)

1. **Copy the folders** into the project root:
   - `lib/nzihl/` → your `lib/` (or `src/lib/`)
   - `app/api/nzihl/` → your `app/api/`
   - one scheduler file (see step 4)

2. **One dependency:**
   ```bash
   npm install cheerio
   ```

3. **Import alias.** The routes import `@/lib/nzihl`. If your `tsconfig.json` maps
   `@/*` to the project root (or `src/`), you're done. Otherwise either add the
   alias or change the imports to a relative path (e.g. `../../../../lib/nzihl`).

4. **Pick a scheduler and set its secret** (see [Scheduling](#scheduling)).

5. **Wire the three sections** (see [Wiring the sections](#wiring-the-sections)).

That's it — `getFixtures()`, `getStandings()` and `getTopScorers()` now return live data.

---

## Wiring the sections

Each section just needs its data swapped. Two ways — pick whichever matches how
the section is built today.

### Option 1 — fetch the API route (works for client or server components)

```tsx
// Fixtures section
import type { Fixtures } from '@/lib/nzihl';

const res = await fetch('/api/nzihl/fixtures'); // standings | scorers
const { games }: Fixtures = await res.json();
// render `games` with your existing card markup
```

### Option 2 — call the data layer directly (Server Components, no API hop)

```tsx
// app/page.tsx (or wherever the section lives)
import { getStandings } from '@/lib/nzihl';

export const revalidate = 21600; // optional ISR baseline

export default async function Page() {
  const { teams } = await getStandings();
  return <StandingsTable rows={teams} />;
}
```

### Field mapping (what the old hardcoded data maps to)

**Standings** (`teams: StandingRow[]`) — `pos`, `name` (short, e.g. "Red Devils"),
`gp`, `w`, `l`, `otw`, `otl`, `pts`. The current table shows `POS / TEAM / GP / W-L / PTS`,
so render `W-L` as `${w}-${l}`. Highlight the Red Devils row with `code === 'CRD'`.

**Top Scorers** (`players: Scorer[]`) — `number`, `name`, `position`, `goals`,
`assists`, `points`. The card shows the number, name, `${position} · #${number}`,
the big `points` value, and `G ${goals} · A ${assists}`.

**Fixtures** (`games: Fixture[]`, full season, chronological) — each game has raw
`homeCode/awayCode/homeScore/awayScore` plus Red-Devils-perspective helpers:
`isHome`, `opponentCode`, `teamScore`, `opponentScore`, `result` ("W"/"L"/"OTL"),
`status` ("final"/"final-ot"/"upcoming"), and `date`/`weekday`/`time`. For the
button: home games → `ticketsUrl`, away games → `streamUrl`. Mark the next game as
the first one with `status === 'upcoming'`.

> `date` is ISO (`2026-06-12`) and `time` is as NZIHL prints it (`7:00PM`). Format
> them however the current cards do (e.g. "12 JUN", "19:00").

Every response also includes `updated` (ISO timestamp) and `source`
(`"live"` or `"fallback"`) if you want to surface freshness or debug.

---

## Scheduling

The data is cached and refreshed on demand by hitting **`/api/nzihl/revalidate`**,
which busts the cache so the next visitor triggers a fresh scrape. A scheduled job
calls that endpoint Fri/Sat/Sun at 11pm NZ. Pick **one** option.

NZ has no daylight saving during the hockey season, but to stay correct year-round
both schedulers fire at **11:00 UTC** (= 11pm NZST, winter) **and 10:00 UTC**
(= 11pm NZDT, summer). Running twice is harmless — it just refreshes the cache.

### Option A — Vercel Cron (if hosted on Vercel)

Keep `vercel.json`, delete the GitHub workflow. Set an env var:

```
CRON_SECRET = <any long random string>
```

Vercel automatically sends `Authorization: Bearer <CRON_SECRET>` to the cron path,
which the revalidate route checks. (Vercel Hobby allows up to 2 cron jobs — this
uses exactly 2.)

### Option B — GitHub Action (any host)

Keep `.github/workflows/nzihl-refresh.yml`, delete `vercel.json`. Set:

- Site env var: `NZIHL_REVALIDATE_SECRET = <long random string>`
- GitHub repo secrets (Settings → Secrets and variables → Actions):
  - `SITE_URL` = `https://reddevils.co.nz` (no trailing slash)
  - `NZIHL_REVALIDATE_SECRET` = the same value as above

Trigger a manual run from the **Actions** tab to test.

---

## Configuration

Everything tunable is in `lib/nzihl/config.ts`:

- `TOP_SCORERS_COUNT` — how many scorers to show (default 4)
- `NAME_OVERRIDES` — fix any name NZIHL stores oddly (example included)
- `TEAMS_BY_LOGO` / `SHORT_NAMES` — add a team or change a display name
- `NZIHL.season` — bump for the next season (the scoreboard omits the year)
- `CACHE_TTL_SECONDS` — baseline freshness between scheduled refreshes

If the league ever changes team IDs, update `NZIHL` in `config.ts` — nothing else.

---

## How it works / reliability

- Reads the league's `printPage` views (clean, server-rendered HTML — no JS, no
  API key, no login).
- Each parser was validated against the live pages before shipping.
- If a scrape ever fails (network blip or a page-structure change), the function
  logs a warning and returns the **fallback snapshot** in `fallback.ts` so the
  section never renders empty. `source: "fallback"` flags this. Refresh the
  snapshot occasionally by pasting a recent live response into `fallback.ts`.
- `runtime = 'nodejs'` is set on the routes (cheerio needs Node, not Edge).

---

## Pages Router

The data layer (`lib/nzihl`) is unchanged. Replace the App Router routes with API
routes and use ISR or on-demand revalidation:

```ts
// pages/api/nzihl/fixtures.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { getFixtures } from '@/lib/nzihl';

export default async function handler(_req: NextApiRequest, res: NextApiResponse) {
  res.setHeader('Cache-Control', 'public, s-maxage=21600, stale-while-revalidate=86400');
  res.json(await getFixtures());
}
```

For scheduled refresh with the Pages Router, prefer ISR (`getStaticProps` with
`revalidate`) on the page, or call `res.revalidate('/')` from a secured
`pages/api/nzihl/revalidate.ts` hit by the same Vercel Cron / GitHub Action.

---

## Quick test after install

```bash
npm run dev
# then:
curl localhost:3000/api/nzihl/standings | jq
curl localhost:3000/api/nzihl/scorers   | jq
curl localhost:3000/api/nzihl/fixtures  | jq '.games | length'   # expect ~16
```

Each should return `"source": "live"`. Then trigger the scheduler manually once to
confirm the refresh path works.
