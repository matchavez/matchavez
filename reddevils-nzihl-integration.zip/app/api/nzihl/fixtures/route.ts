// GET /api/nzihl/fixtures  ->  Fixtures (full Red Devils season)
//
// Data is cached with the 'nzihl' tag and revalidated by /api/nzihl/revalidate
// (called by the scheduled job). Baseline TTL is CACHE_TTL_SECONDS.

import { NextResponse } from 'next/server';
import { unstable_cache } from 'next/cache';
import { getFixtures } from '@/lib/nzihl';
import { CACHE_TTL_SECONDS } from '@/lib/nzihl/config';

export const runtime = 'nodejs';      // cheerio needs the Node runtime
export const dynamic = 'force-dynamic'; // route always runs; caching is at the data layer

const cachedFixtures = unstable_cache(getFixtures, ['nzihl-fixtures'], {
  tags: ['nzihl'],
  revalidate: CACHE_TTL_SECONDS,
});

export async function GET() {
  const data = await cachedFixtures();
  return NextResponse.json(data, {
    headers: {
      'Cache-Control': `public, s-maxage=${CACHE_TTL_SECONDS}, stale-while-revalidate=86400`,
    },
  });
}
