// GET|POST /api/nzihl/revalidate  ->  force-refresh all NZIHL data
//
// Called by the scheduled job (Vercel Cron or GitHub Action) after each game
// weekend. Busts the 'nzihl' cache tag so the next request re-scrapes live.
//
// Auth — either is accepted:
//   • Vercel Cron:   sends `Authorization: Bearer <CRON_SECRET>` automatically
//                    when the CRON_SECRET env var is set.
//   • GitHub Action / manual:  ?secret=<NZIHL_REVALIDATE_SECRET>
//
// Set at least one of CRON_SECRET / NZIHL_REVALIDATE_SECRET in your env.

import { NextResponse } from 'next/server';
import { revalidateTag } from 'next/cache';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

function authorized(req: Request): boolean {
  const cronSecret = process.env.CRON_SECRET;
  const querySecret = process.env.NZIHL_REVALIDATE_SECRET;

  // Vercel Cron header
  if (cronSecret) {
    const auth = req.headers.get('authorization');
    if (auth === `Bearer ${cronSecret}`) return true;
  }
  // Query-string secret (GitHub Action / manual trigger)
  if (querySecret) {
    const secret = new URL(req.url).searchParams.get('secret');
    if (secret && secret === querySecret) return true;
  }
  return false;
}

async function handle(req: Request) {
  if (!authorized(req)) {
    return NextResponse.json({ ok: false, error: 'unauthorized' }, { status: 401 });
  }
  revalidateTag('nzihl');
  return NextResponse.json({ ok: true, revalidated: true, now: Date.now() });
}

export const GET = handle;
export const POST = handle;
