// GET /api/nzihl/scorers  ->  TopScorers (Red Devils points leaders)

import { NextResponse } from 'next/server';
import { unstable_cache } from 'next/cache';
import { getTopScorers } from '@/lib/nzihl';
import { CACHE_TTL_SECONDS } from '@/lib/nzihl/config';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const cachedScorers = unstable_cache(getTopScorers, ['nzihl-scorers'], {
  tags: ['nzihl'],
  revalidate: CACHE_TTL_SECONDS,
});

export async function GET() {
  const data = await cachedScorers();
  return NextResponse.json(data, {
    headers: {
      'Cache-Control': `public, s-maxage=${CACHE_TTL_SECONDS}, stale-while-revalidate=86400`,
    },
  });
}
