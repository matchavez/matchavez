// GET /api/nzihl/standings  ->  Standings (NZIHL league table)

import { NextResponse } from 'next/server';
import { unstable_cache } from 'next/cache';
import { getStandings } from '@/lib/nzihl';
import { CACHE_TTL_SECONDS } from '@/lib/nzihl/config';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const cachedStandings = unstable_cache(getStandings, ['nzihl-standings'], {
  tags: ['nzihl'],
  revalidate: CACHE_TTL_SECONDS,
});

export async function GET() {
  const data = await cachedStandings();
  return NextResponse.json(data, {
    headers: {
      'Cache-Control': `public, s-maxage=${CACHE_TTL_SECONDS}, stale-while-revalidate=86400`,
    },
  });
}
