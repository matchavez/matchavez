// ---------------------------------------------------------------------------
// NZIHL integration — configuration
// All tunables live here. Editing this file should be enough to adjust the
// integration without touching parsing/fetching logic.
// ---------------------------------------------------------------------------

export const NZIHL = {
  clientId: 7131,
  leagueId: 35499,
  redDevilsTeamId: 675633,
  season: 2026, // used to build ISO dates (the NZIHL scoreboard omits the year)
} as const;

const { clientId, leagueId, redDevilsTeamId } = NZIHL;

// Official NZIHL (esportsdesk) source URLs. The `printPage=1` views return clean,
// server-rendered HTML (no JavaScript required), which is what we parse.
export const URLS = {
  // Clean single-table standings
  standings: `https://www.nzihl.com/leagues/standings.cfm?clientid=${clientId}&leagueid=${leagueId}&printPage=1`,
  // Full-season scoreboard (all games, with ticket/stream links) lives on the
  // non-print standings page. We filter it down to Red Devils games.
  scoreboard: `https://www.nzihl.com/leagues/standings.cfm?clientid=${clientId}&leagueid=${leagueId}`,
  // Red Devils full player stats (skaters), used for top scorers
  teamStats: `https://www.nzihl.com/leagues/stats_1team.cfm?clientID=${clientId}&leagueID=${leagueId}&teamID=${redDevilsTeamId}&printPage=1`,
} as const;

// How many scorers the "Top Scorers" section shows.
export const TOP_SCORERS_COUNT = 4;

// Our team's code (as it appears in the scoreboard logos).
export const OUR_CODE = 'CRD';

// Map a fragment of the NZIHL logo filename -> team code + short display name.
// The scoreboard identifies teams by their logo image, so this is how we know
// who's playing. Add a new entry here if the league adds a team.
export const TEAMS_BY_LOGO: Record<string, { code: string; name: string }> = {
  reddevils: { code: 'CRD', name: 'Red Devils' },
  stampede:  { code: 'SCS', name: 'Stampede' },
  thunder:   { code: 'DUN', name: 'Thunder' },
  swarm:     { code: 'BSW', name: 'Swarm' },
  admirals:  { code: 'WAA', name: 'Admirals' },
};

// Map the full team name (as printed in the standings table) -> the short name
// used on reddevils.co.nz. Falls back to the last word if not listed.
export const SHORT_NAMES: Record<string, string> = {
  'SkyCity Stampede': 'Stampede',
  'Pure NZ Admirals': 'Admirals',
  'Dunedin Thunder': 'Thunder',
  'Botany Swarm': 'Swarm',
  'Canterbury Red Devils': 'Red Devils',
};

// Default stream URL when the league's per-game link is missing.
export const STREAM_URL = 'https://www.youtube.com/nzihl';

// Optional manual corrections to player names. NZIHL occasionally stores names
// in odd casing or with a different first name. Key = the name exactly as NZIHL
// stores it, lower-cased; value = the corrected display name.
//   e.g. 'garth henare': 'Te Rangi Henare',
export const NAME_OVERRIDES: Record<string, string> = {};

// Network timeout for each NZIHL request (ms).
export const REQUEST_TIMEOUT_MS = 12000;

// Baseline cache lifetime for the API routes (seconds). The scheduled job
// force-refreshes on top of this after each game weekend.
export const CACHE_TTL_SECONDS = 21600; // 6 hours
