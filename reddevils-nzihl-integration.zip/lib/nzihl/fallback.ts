// ---------------------------------------------------------------------------
// NZIHL integration — fallback snapshot
// Used only when a live scrape fails (network blip or the league page changes),
// so a section never renders empty. Snapshot taken 2026-06-09 from live NZIHL.
// Refresh occasionally by copying a recent live API response in here.
// ---------------------------------------------------------------------------

import type { Standings, TopScorers, Fixtures } from './types';
import { STREAM_URL } from './config';

const SNAPSHOT_DATE = '2026-06-09T00:00:00.000Z';

export const FALLBACK_STANDINGS: Standings = {
  updated: SNAPSHOT_DATE,
  source: 'fallback',
  teams: [
    { pos: 1, code: 'SCS', name: 'Stampede',   fullName: 'SkyCity Stampede',      gp: 8, w: 5, l: 1, otw: 2, otl: 0, pts: 19 },
    { pos: 2, code: 'WAA', name: 'Admirals',   fullName: 'Pure NZ Admirals',      gp: 8, w: 4, l: 4, otw: 0, otl: 0, pts: 12 },
    { pos: 3, code: 'DUN', name: 'Thunder',    fullName: 'Dunedin Thunder',       gp: 6, w: 3, l: 3, otw: 0, otl: 0, pts: 9 },
    { pos: 4, code: 'BSW', name: 'Swarm',      fullName: 'Botany Swarm',          gp: 6, w: 2, l: 3, otw: 0, otl: 1, pts: 7 },
    { pos: 5, code: 'CRD', name: 'Red Devils', fullName: 'Canterbury Red Devils', gp: 8, w: 2, l: 5, otw: 0, otl: 1, pts: 7 },
  ],
};

export const FALLBACK_SCORERS: TopScorers = {
  updated: SNAPSHOT_DATE,
  source: 'fallback',
  players: [
    { name: 'Alex Gagnon',       number: '88', position: 'F', goals: 12, assists: 8,  points: 20 },
    { name: 'Fabian Hast',       number: '48', position: 'F', goals: 2,  assists: 15, points: 17 },
    { name: 'Michael Morrissey', number: '21', position: 'F', goals: 6,  assists: 2,  points: 8 },
    { name: 'Luke Tappin',       number: '22', position: 'D', goals: 3,  assists: 5,  points: 8 },
  ],
};

// Helper to keep the fixtures snapshot compact and consistent.
function game(
  date: string, weekday: string, time: string, status: Fixtures['games'][number]['status'],
  homeCode: string, homeName: string, awayCode: string, awayName: string,
  homeScore: number | null, awayScore: number | null,
  ticketsUrl: string | null, boxscoreUrl: string | null,
): Fixtures['games'][number] {
  const isHome = homeCode === 'CRD';
  const opp = isHome ? { code: awayCode, name: awayName } : { code: homeCode, name: homeName };
  const teamScore = isHome ? homeScore : awayScore;
  const opponentScore = isHome ? awayScore : homeScore;
  let result: Fixtures['games'][number]['result'] = null;
  if (teamScore != null && opponentScore != null) {
    result = teamScore > opponentScore ? 'W' : status === 'final-ot' ? 'OTL' : 'L';
  }
  return {
    date, weekday, time, status,
    homeCode, awayCode, homeName, awayName, homeScore, awayScore,
    isHome, opponentCode: opp.code, opponentName: opp.name,
    teamScore, opponentScore, result,
    ticketsUrl, streamUrl: STREAM_URL, boxscoreUrl,
  };
}

const ROLLER = (id: string, date: string) =>
  `https://ecom.roller.app/alpineice/booknow/en/product/${id}?date=${date}`;
const DUN_TIX = 'https://www.dunedinicehockey.co.nz/game-tickets/';

export const FALLBACK_FIXTURES: Fixtures = {
  updated: SNAPSHOT_DATE,
  source: 'fallback',
  games: [
    game('2026-05-09', 'SAT', '4:45PM', 'final',    'WAA', 'Admirals', 'CRD', 'Red Devils', 7, 2, null, null),
    game('2026-05-10', 'SUN', '6:00PM', 'final',    'WAA', 'Admirals', 'CRD', 'Red Devils', 5, 3, null, null),
    game('2026-05-15', 'FRI', '7:00PM', 'final',    'SCS', 'Stampede', 'CRD', 'Red Devils', 5, 3, null, null),
    game('2026-05-16', 'SAT', '7:00PM', 'final-ot', 'SCS', 'Stampede', 'CRD', 'Red Devils', 4, 3, null, null),
    game('2026-05-23', 'SAT', '5:10PM', 'final',    'CRD', 'Red Devils', 'BSW', 'Swarm', 4, 6, null, null),
    game('2026-05-24', 'SUN', '5:10PM', 'final',    'CRD', 'Red Devils', 'BSW', 'Swarm', 5, 4, null, null),
    game('2026-06-06', 'SAT', '5:10PM', 'final',    'CRD', 'Red Devils', 'WAA', 'Admirals', 1, 4, null, null),
    game('2026-06-07', 'SUN', '5:10PM', 'final',    'CRD', 'Red Devils', 'WAA', 'Admirals', 8, 2, null, null),
    game('2026-06-12', 'FRI', '7:00PM', 'upcoming', 'DUN', 'Thunder', 'CRD', 'Red Devils', null, null, DUN_TIX, null),
    game('2026-06-13', 'SAT', '6:00PM', 'upcoming', 'DUN', 'Thunder', 'CRD', 'Red Devils', null, null, DUN_TIX, null),
    game('2026-06-27', 'SAT', '5:10PM', 'upcoming', 'CRD', 'Red Devils', 'DUN', 'Thunder', null, null, ROLLER('1014053', '2026-06-27'), null),
    game('2026-06-28', 'SUN', '5:10PM', 'upcoming', 'CRD', 'Red Devils', 'DUN', 'Thunder', null, null, ROLLER('1014053', '2026-06-28'), null),
    game('2026-07-18', 'SAT', '5:10PM', 'upcoming', 'CRD', 'Red Devils', 'SCS', 'Stampede', null, null, ROLLER('1014046', '2026-07-18'), null),
    game('2026-07-19', 'SUN', '5:10PM', 'upcoming', 'CRD', 'Red Devils', 'SCS', 'Stampede', null, null, ROLLER('1014046', '2026-07-19'), null),
    game('2026-07-25', 'SAT', '4:45PM', 'upcoming', 'BSW', 'Swarm', 'CRD', 'Red Devils', null, null, null, null),
    game('2026-07-26', 'SUN', '4:45PM', 'upcoming', 'BSW', 'Swarm', 'CRD', 'Red Devils', null, null, null, null),
  ],
};
