// ---------------------------------------------------------------------------
// NZIHL integration — low-level HTML fetcher
// Uses the global fetch (Node 18+ / all Next.js runtimes). Adds a timeout and
// a descriptive User-Agent. No caching here — caching is handled by the API
// routes so the same data layer can be reused anywhere.
// ---------------------------------------------------------------------------

import { REQUEST_TIMEOUT_MS } from './config';

export async function fetchHtml(url: string): Promise<string> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      // Always hit the origin; the API route layer adds caching/revalidation.
      cache: 'no-store',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (compatible; RedDevilsSiteBot/1.0; +https://reddevils.co.nz)',
        Accept: 'text/html,application/xhtml+xml',
      },
    });
    if (!res.ok) {
      throw new Error(`NZIHL request failed: ${res.status} ${res.statusText} (${url})`);
    }
    return await res.text();
  } finally {
    clearTimeout(timeout);
  }
}
