// ---------------------------------------------------------------------------
// NZIHL integration — public API
//
//   import { getFixtures, getStandings, getTopScorers } from '@/lib/nzihl';
//
// Each function fetches + parses live NZIHL data and returns a typed object.
// If a scrape fails it logs and returns the built-in fallback snapshot, so a
// section never renders empty. `result.source` tells you which you got.
//
// This module is framework-agnostic (no Next.js imports). Caching/scheduling
// is handled in the API route layer.
// ---------------------------------------------------------------------------

import { URLS, TOP_SCORERS_COUNT } from './config';
import { fetchHtml } from './fetcher';
import { parseStandings, parseTopScorers, parseFixtures } from './parse';
import { FALLBACK_STANDINGS, FALLBACK_SCORERS, FALLBACK_FIXTURES } from './fallback';
import type { Standings, TopScorers, Fixtures } from './types';

const nowIso = () => new Date().toISOString();

export async function getStandings(): Promise<Standings> {
  try {
    const teams = parseStandings(await fetchHtml(URLS.standings));
    if (!teams.length) throw new Error('parsed 0 standings rows');
    return { updated: nowIso(), source: 'live', teams };
  } catch (err) {
    console.error('[nzihl] standings scrape failed — using fallback:', err);
    return FALLBACK_STANDINGS;
  }
}

export async function getTopScorers(): Promise<TopScorers> {
  try {
    const players = parseTopScorers(await fetchHtml(URLS.teamStats), TOP_SCORERS_COUNT);
    if (!players.length) throw new Error('parsed 0 scorers');
    return { updated: nowIso(), source: 'live', players };
  } catch (err) {
    console.error('[nzihl] top scorers scrape failed — using fallback:', err);
    return FALLBACK_SCORERS;
  }
}

export async function getFixtures(): Promise<Fixtures> {
  try {
    const games = parseFixtures(await fetchHtml(URLS.scoreboard));
    if (!games.length) throw new Error('parsed 0 fixtures');
    return { updated: nowIso(), source: 'live', games };
  } catch (err) {
    console.error('[nzihl] fixtures scrape failed — using fallback:', err);
    return FALLBACK_FIXTURES;
  }
}

export type {
  Standings, StandingRow,
  TopScorers, Scorer,
  Fixtures, Fixture, FixtureStatus, FixtureResult,
  DataSource,
} from './types';
