// ---------------------------------------------------------------------------
// NZIHL integration — HTML parsers (cheerio)
// These parse the official NZIHL (esportsdesk) pages into clean typed objects.
// Each parser was validated against the live pages.
// ---------------------------------------------------------------------------

import * as cheerio from 'cheerio';
import {
  NZIHL,
  SHORT_NAMES,
  TEAMS_BY_LOGO,
  NAME_OVERRIDES,
  STREAM_URL,
  TOP_SCORERS_COUNT,
} from './config';
import type { StandingRow, Scorer, Fixture, FixtureStatus, FixtureResult } from './types';

const MONTHS: Record<string, string> = {
  JAN: '01', FEB: '02', MAR: '03', APR: '04', MAY: '05', JUN: '06',
  JUL: '07', AUG: '08', SEP: '09', OCT: '10', NOV: '11', DEC: '12',
};

function titleCase(s: string): string {
  return s
    .toLowerCase()
    .replace(/(^|[\s'\-])([a-z])/g, (_m, p, c) => p + c.toUpperCase())
    .trim();
}

function teamFromLogo(filename: string): { code: string; name: string } | null {
  const fn = (filename || '').toLowerCase();
  for (const key of Object.keys(TEAMS_BY_LOGO)) {
    if (fn.includes(key)) return TEAMS_BY_LOGO[key];
  }
  return null;
}

function classifyLink(href: string): 'box' | 'stream' | 'tickets' | null {
  const h = (href || '').toLowerCase();
  if (h.includes('boxscore')) return 'box';
  if (h.includes('youtube') || h.includes('youtu.be')) return 'stream';
  if (
    h.includes('roller') || h.includes('eventfinda') || h.includes('aiha') ||
    h.includes('dunedin') || h.includes('icehockeynz') || h.includes('ticket')
  ) return 'tickets';
  return null;
}

function absolute(href: string): string {
  if (!href) return href;
  if (href.startsWith('http')) return href;
  return `https://www.nzihl.com${href.startsWith('/') ? '' : '/'}${href}`;
}

// --- Standings -------------------------------------------------------------

export function parseStandings(html: string): StandingRow[] {
  const $ = cheerio.load(html);
  const table = $('table').first();
  if (!table.length) return [];

  const headers = table.find('tr').first().find('th,td').map((_i, el) => $(el).text().trim()).get();
  const col = (n: string) => headers.indexOf(n);
  const ci = {
    team: col('Team'), gp: col('GP'), w: col('W'), l: col('L'),
    otw: col('OTW'), otl: col('OTL'), pts: col('PTS'),
  };

  const rows: StandingRow[] = [];
  table.find('tr').slice(1).each((_i, tr) => {
    const tds = $(tr).find('td');
    if (!tds.length) return;
    const cell = (j: number) => (j >= 0 ? tds.eq(j).text().trim() : '');
    const raw = cell(ci.team);
    if (!raw) return;

    const codeMatch = raw.match(/([A-Z]{2,3})$/);
    const code = codeMatch ? codeMatch[1] : '';
    const fullName = raw.replace(/[A-Z]{2,3}$/, '').trim();

    rows.push({
      pos: rows.length + 1,
      code,
      fullName,
      name: SHORT_NAMES[fullName] || fullName.split(' ').pop() || fullName,
      gp: Number(cell(ci.gp)) || 0,
      w: Number(cell(ci.w)) || 0,
      l: Number(cell(ci.l)) || 0,
      otw: Number(cell(ci.otw)) || 0,
      otl: Number(cell(ci.otl)) || 0,
      pts: Number(cell(ci.pts)) || 0,
    });
  });
  return rows;
}

// --- Top scorers -----------------------------------------------------------

export function parseTopScorers(html: string, count: number = TOP_SCORERS_COUNT): Scorer[] {
  const $ = cheerio.load(html);

  // Find the skater table (has Position + PTS columns; goalie table does not).
  let table: any = null;
  $('table').each((_i, t) => {
    if (table) return;
    const h = $(t).find('tr').first().find('th,td').map((_j, el) => $(el).text().trim()).get();
    if (h.includes('Position') && h.includes('PTS') && h.includes('A')) table = $(t);
  });
  if (!table) return [];

  const headers = table.find('tr').first().find('th,td').map((_i, el) => $(el).text().trim()).get();
  const col = (n: string) => headers.indexOf(n);
  const ci = {
    player: col('Player'), num: col('#'), pos: col('Position'),
    g: col('G'), a: col('A'), pts: col('PTS'),
  };

  const players: Scorer[] = [];
  table.find('tr').slice(1).each((_i, tr) => {
    const tds = $(tr).find('td');
    if (!tds.length) return;

    const playerCell = tds.eq(ci.player);
    const titled = playerCell.find('a[title]').first();
    const raw = (titled.length ? titled.attr('title') || '' : playerCell.text()).trim();
    if (!raw || /team totals/i.test(raw)) return;

    const pts = parseInt(tds.eq(ci.pts).text(), 10);
    if (isNaN(pts)) return;

    players.push({
      name: NAME_OVERRIDES[raw.toLowerCase()] || titleCase(raw),
      number: tds.eq(ci.num).text().trim(),
      position: tds.eq(ci.pos).text().trim(),
      goals: parseInt(tds.eq(ci.g).text(), 10) || 0,
      assists: parseInt(tds.eq(ci.a).text(), 10) || 0,
      points: pts,
    });
  });

  players.sort((a, b) => b.points - a.points || b.goals - a.goals || b.assists - a.assists);
  return players.slice(0, count);
}

// --- Fixtures --------------------------------------------------------------

export function parseFixtures(html: string): Fixture[] {
  const $ = cheerio.load(html);
  const games: Fixture[] = [];

  $('div.col.mx-1').each((_i, block) => {
    const $b = $(block);

    const logos = $b.find('img').map((_j, el) => ($(el).attr('src') || '').split('/').pop() || '').get();
    const teams = logos.map(teamFromLogo).filter(Boolean) as { code: string; name: string }[];
    if (teams.length < 2) return; // not a game block (e.g. playoff placeholders)

    const away = teams[0];
    const home = teams[1];
    if (away.code !== 'CRD' && home.code !== 'CRD') return; // Red Devils games only

    const text = $b.text().replace(/\s+/g, ' ').trim();
    const status: FixtureStatus = /FINAL\/OT/i.test(text)
      ? 'final-ot'
      : /\bFINAL\b/i.test(text)
      ? 'final'
      : 'upcoming';

    // "SAT 9 MAY. at 4:45PM ..." -> weekday / day / month / time
    const m = text.match(/^([A-Z]{3})\s+(\d{1,2})\s+([A-Z]{3})\.?\s+at\s+([\d:]+\s*[AP]M)/i);
    let date: string | null = null;
    let weekday: string | null = null;
    let time: string | null = null;
    let after = text;
    if (m) {
      weekday = m[1].toUpperCase();
      const day = m[2].padStart(2, '0');
      const mon = MONTHS[m[3].toUpperCase()] || '00';
      time = m[4].replace(/\s+/g, '');
      date = `${NZIHL.season}-${mon}-${day}`;
      after = text.slice(m[0].length);
    }

    // Scores follow the away/home order; only present for finished games.
    let awayScore: number | null = null;
    let homeScore: number | null = null;
    if (status !== 'upcoming') {
      const nums = (after.match(/\d+/g) || []).map(Number);
      if (nums.length >= 2) {
        awayScore = nums[0];
        homeScore = nums[1];
      }
    }

    const links: Record<string, string> = {};
    $b.find('a').each((_j, a) => {
      const href = $(a).attr('href') || '';
      const t = classifyLink(href);
      if (t && !links[t]) links[t] = absolute(href);
    });

    const isHome = home.code === 'CRD';
    const opponent = isHome ? away : home;
    const teamScore = isHome ? homeScore : awayScore;
    const opponentScore = isHome ? awayScore : homeScore;

    let result: FixtureResult = null;
    if (teamScore != null && opponentScore != null) {
      result = teamScore > opponentScore ? 'W' : status === 'final-ot' ? 'OTL' : 'L';
    }

    games.push({
      date, weekday, time, status,
      homeCode: home.code, awayCode: away.code,
      homeName: home.name, awayName: away.name,
      homeScore, awayScore,
      isHome,
      opponentCode: opponent.code, opponentName: opponent.name,
      teamScore, opponentScore, result,
      ticketsUrl: links['tickets'] || null,
      streamUrl: links['stream'] || STREAM_URL,
      boxscoreUrl: links['box'] || null,
    });
  });

  // Chronological order (scoreboard is already ordered, but be safe).
  games.sort((a, b) => (a.date || '').localeCompare(b.date || ''));
  return games;
}
