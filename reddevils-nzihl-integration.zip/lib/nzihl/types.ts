// ---------------------------------------------------------------------------
// NZIHL integration — shared types
// Import these in your components for full type-safety.
// ---------------------------------------------------------------------------

/** Where the data came from on this request. */
export type DataSource = 'live' | 'fallback';

// --- Standings -------------------------------------------------------------

export interface StandingRow {
  pos: number;       // 1-based league position (as ordered by NZIHL)
  code: string;      // team code, e.g. "CRD"
  name: string;      // short display name, e.g. "Red Devils"
  fullName: string;  // full name, e.g. "Canterbury Red Devils"
  gp: number;        // games played
  w: number;         // regulation wins
  l: number;         // regulation losses
  otw: number;       // overtime/shootout wins
  otl: number;       // overtime/shootout losses
  pts: number;       // total points
}

export interface Standings {
  updated: string;       // ISO timestamp of this fetch
  source: DataSource;
  teams: StandingRow[];
}

// --- Top scorers -----------------------------------------------------------

export interface Scorer {
  name: string;      // display name, e.g. "Alex Gagnon"
  number: string;    // jersey number, e.g. "88"
  position: string;  // "F" | "D"
  goals: number;
  assists: number;
  points: number;
}

export interface TopScorers {
  updated: string;
  source: DataSource;
  players: Scorer[];
}

// --- Fixtures --------------------------------------------------------------

export type FixtureStatus = 'final' | 'final-ot' | 'upcoming';
export type FixtureResult = 'W' | 'L' | 'OTL' | null;

export interface Fixture {
  date: string | null;     // "YYYY-MM-DD"
  weekday: string | null;  // "SAT"
  time: string | null;     // "5:10PM" (as published by NZIHL)
  status: FixtureStatus;

  // Raw home/away as published by the league
  homeCode: string;
  awayCode: string;
  homeName: string;
  awayName: string;
  homeScore: number | null;
  awayScore: number | null;

  // Convenience fields from the Red Devils' perspective
  isHome: boolean;            // true when the Red Devils are the home team
  opponentCode: string;
  opponentName: string;
  teamScore: number | null;   // Red Devils' score (null if upcoming)
  opponentScore: number | null;
  result: FixtureResult;      // "W" | "L" | "OTL" for finished games

  // Links (whichever the league provides for that game)
  ticketsUrl: string | null;
  streamUrl: string | null;
  boxscoreUrl: string | null;
}

export interface Fixtures {
  updated: string;
  source: DataSource;
  games: Fixture[]; // full season, in chronological order
}
